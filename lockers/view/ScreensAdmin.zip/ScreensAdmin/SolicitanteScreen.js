import React, { useState, useEffect } from 'react';
import { View, FlatList, StyleSheet, Text, ActivityIndicator } from 'react-native';
import { IP_ADDRESS } from '../../env';

export default function SolicitantesScreen() {
  const [solicitante, listaSoli] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const getSoli = async () => {
      try {
        const response = await fetch(`http://${IP_ADDRESS}:9000/solicitante`);
        const data = await response.json();
        listaSoli(data);
        setIsLoading(false);
      } catch (error) {
        console.error('Error fetching data:', error);
        setIsLoading(false);
      }
    }

    getSoli();
  }, []);

  const renderItem = ({ item }) => (
    <View style={styles.solicitanteContainer}>
      <View style={styles.rowContainer}>
        <Text style={styles.titleText}>Solicitante:</Text>
        <Text style={styles.solicitanteText}>{item.Solicitante}</Text>
      </View>
      <View style={styles.rowContainer}>
        <Text style={styles.titleText}>Teléfono:</Text>
        <Text style={styles.solicitanteText}>{item.Telefono}</Text>
      </View>
      <View style={styles.rowContainer}>
        <Text style={styles.titleText}>Email:</Text>
        <Text style={styles.solicitanteText}>{item.Email}</Text>
      </View>
      <View style={styles.rowContainer}>
        <Text style={styles.titleText}>Departamento:</Text>
        <Text style={styles.solicitanteText}>{item.Departamento}</Text>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      {isLoading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="green" />
          <Text>Loading Data</Text>
        </View>
      ) : (
        <FlatList
          data={solicitante}
          renderItem={renderItem}
          keyExtractor={(item, index) => index.toString()}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#fff',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  solicitanteContainer: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    marginBottom: 10,
    padding: 10,
    backgroundColor: '#f0f0f0', // Color de fondo del contenedor
  },
  rowContainer: {
    flexDirection: 'row',
    marginBottom: 5,
  },
  titleText: {
    fontWeight: 'bold',
    marginRight: 5,
  },
  solicitanteText: {
    flex: 1,
    textAlign: 'center',
  },
});

