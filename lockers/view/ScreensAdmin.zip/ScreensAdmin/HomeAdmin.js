import React from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import { useNavigation } from '@react-navigation/native';

import { useRoute } from '@react-navigation/native';
export default function HomeAdmin() {
    const route = useRoute();
    const { params } = route;
    const { numero } = params || {};
    return (
        <View>
            <Text style={styles.text}>Bienvenido Administrador {numero}</Text>
        </View>
    );
}

const styles = StyleSheet.create({
    text: {
        fontSize: 28,
        alignItems: "center",
    },
    textTouch: {
        fontSize: 16,
        color: "white",
        alignItems: "center",
    },
    buttonOp: {
        backgroundColor: "purple",
        padding: 10,
        margin: 10
    },
})