import React, { useState, useEffect } from 'react';
import { View, ScrollView, StyleSheet, Text, ActivityIndicator, FlatList } from 'react-native';
import { useTable } from 'react-table';
import { IP_ADDRESS } from '../../env';

export default function HistorialPago() {
  const [pago, historialPago] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const getPago = async () => {
      try {
        const response = await fetch(`http://${IP_ADDRESS}:9000/historialPago`);
        const data = await response.json();
        historialPago(data);
        setIsLoading(false);
      } catch (error) {
        console.error('Error fetching data:', error);
        setIsLoading(false);
      }
    };

    getPago();
  }, []);

  const renderItem = ({ item }) => (
    <View style={styles.PagoContainer}>
      <View style={styles.rowContainer}>
        <Text style={styles.titleText}>Solicitante:</Text>
        <Text style={styles.PagoText}>{item.Solicitante}</Text>
      </View>
      <View style={styles.rowContainer}>
        <Text style={styles.titleText}>Fecha:</Text>
        <Text style={styles.PagoText}>{item.Fecha}</Text>
      </View>
      <View style={styles.rowContainer}>
        <Text style={styles.titleText}>Monto:</Text>
        <Text style={styles.PagoText}>{item.Monto}</Text>
      </View>
      <View style={styles.rowContainer}>
        <Text style={styles.titleText}>Locker:</Text>
        <Text style={styles.PagoText}>{item.Locker}</Text>
      </View>
      <View style={styles.rowContainer}>
        <Text style={styles.titleText}>Estado:</Text>
        <Text style={styles.PagoText}>{item.Estado}</Text>
      </View>
      <View style={styles.rowContainer}>
        <Text style={styles.titleText}>Ubicacion:</Text>
        <Text style={styles.PagoText}>{item.Ubicacion}</Text>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      {isLoading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="green" />
          <Text>Loading Data</Text>
        </View>
      ) : (
        <FlatList
          data={pago}
          renderItem={renderItem}
          keyExtractor={(item, index) => index.toString()}
        />
      )}
    </View>
  );

}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#fff',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  PagoContainer: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    marginBottom: 10,
    padding: 10,
    backgroundColor: '#f0f0f0', 
  },
  rowContainer: {
    flexDirection: 'row',
    marginBottom: 5,
  },
  titleText: {
    fontWeight: 'bold',
    marginRight: 5,
  },
  PagoText: {
    flex: 1,
    marginRight: 6,
  },
});