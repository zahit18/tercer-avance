import React, { useState, useEffect } from 'react';
import { View, Text, ActivityIndicator, StyleSheet, FlatList } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import { IP_ADDRESS } from '../../env';

export default function HistorialRentasScreen() {
  const [rentas, setRentas] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const getRentas = async () => {
      try {
        const response = await fetch(`http://${IP_ADDRESS}:9000/historialRentas`);
        const data = await response.json();
        setRentas(data);
        setIsLoading(false);
      } catch (error) {
        console.error('Error fetching data:', error);
        setIsLoading(false);
      }
    };

    getRentas();
  }, []);

  const renderItem = ({ item }) => (
    <View style={styles.RentasContainer}>
      <View style={styles.rowContainer}>
        <Text style={styles.titleText}>Solicitante:</Text>
        <Text style={styles.ReservaText}>{item.Solicitante}</Text>
      </View>
      <View style={styles.rowContainer}>
        <Text style={styles.titleText}>Locker:</Text>
        <Text style={styles.RentasText}>{item.Lockers}</Text>
      </View>
      <View style={styles.rowContainer}>
        <Text style={styles.titleText}>Tamaño:</Text>
        <Text style={styles.RentasText}>{item.Tamaño}</Text>
      </View>
      <View style={styles.rowContainer}>
        <Text style={styles.titleText}>Ubicacion:</Text>
        <Text style={styles.RentasText}>{item.Ubicacion}</Text>
      </View>
      <View style={styles.rowContainer}>
        <Text style={styles.titleText}>Fecha Inicio:</Text>
        <Text style={styles.RentasText}>{item.Inicio}</Text>
      </View>
      <View style={styles.rowContainer}>
        <Text style={styles.titleText}>Vencimiento:</Text>
        <Text style={styles.RentasText}>{item.Vencimiento}</Text>
      </View>
      <View style={styles.rowContainer}>
        <Text style={styles.titleText}>Estado:</Text>
        <Text style={styles.RentasText}>{item.Estado}</Text>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      {isLoading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="green" />
          <Text>Loading Data</Text>
        </View>
      ) : (
        <FlatList
          data={rentas}
          renderItem={renderItem}
          keyExtractor={(item, index) => index.toString()}
        />
      )}
    </View>
  );
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#fff',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  RentasContainer: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    marginBottom: 10,
    padding: 10,
    backgroundColor: '#f0f0f0', // Color de fondo del contenedor
  },
  rowContainer: {
    flexDirection: 'row',
    marginBottom: 5,
  },
  titleText: {
    fontWeight: 'bold',
    marginRight: 5,
  },
  RentasText: {
    flex: 1,
    marginRight: 6,
  },
});
