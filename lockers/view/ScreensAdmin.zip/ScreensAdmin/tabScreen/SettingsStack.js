import React from 'react';
import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';
import AgregarAdminScreen from '../AgregarAdminScreen';
import EditarUsuarioScreen from '../EditarUsuarioScreen';
import HomeAdmin from '../HomeAdmin';

const TopTab = createMaterialTopTabNavigator();

const SettingsStack = () => {
    return (
        <TopTab.Navigator>
            <TopTab.Screen name="Agregar Administrador" component={AgregarAdminScreen} />
            <TopTab.Screen  name="Editar Usuario" component={EditarUsuarioScreen}  />
        </TopTab.Navigator>
    );
};

export default SettingsStack;


